import 'package:flutter/material.dart';
import 'package:task_manager/main.dart';
import 'package:task_manager/Home Page/addTask.dart';
import 'package:task_manager/Home Page/taskWidget.dart';

class TaskManager extends StatefulWidget {
  const TaskManager({Key? key}) : super(key: key);

  @override
  _TaskManagerState createState() => _TaskManagerState();
}

class _TaskManagerState extends State<TaskManager> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final tabs = [TaskListWidget(), Container(), Container()];

    return Scaffold(
      appBar: AppBar(
        title: Text(MyApp.title),
        centerTitle: true,
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.white.withOpacity(0.7),
        selectedItemColor: Colors.white,
        currentIndex: selectedIndex,
        onTap: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.fact_check_outlined), label: 'Tasks'),
          BottomNavigationBarItem(
              icon: FloatingActionButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AddTask(),
                    ),
                  );
                },
                backgroundColor: Colors.black,
                child: Icon(
                  Icons.add,
                ),
              ),
              label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.done), label: 'Archived'),
        ],
      ),
      body: tabs[selectedIndex],
    );
  }
}
