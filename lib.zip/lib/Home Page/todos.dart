import 'package:flutter/material.dart';
import 'package:task_manager/Home Page/todo.dart';

class TodosProvider extends ChangeNotifier {
  List<Todo> _todos = [
    Todo(
        createdTime: DateTime.now(),
        title: 'Go for a walk',
        description: 'This is the description of this todo'),
    Todo(
        createdTime: DateTime.now(),
        title: 'Go for a walk',
        description: 'This is the description of this todo'),
    Todo(
        createdTime: DateTime.now(),
        title: 'Go for a walk',
        description: 'This is the description of this todo'),
    Todo(
        createdTime: DateTime.now(),
        title: 'Go for a walk',
        description: 'This is the description of this todo'),
  ];

  List<Todo> get todos => _todos.where((todo) => todo.isDone == false).toList();
}
